<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * Module routes for home
 * Version: 2025-10-14_v1
 */

$route['']				= 'home/index'; // root -> home
$route['home']			= 'home/index';
$route['get_started'] 	= 'home/get_started';
