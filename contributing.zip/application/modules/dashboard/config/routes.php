<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * Module routes for dashboard
 * Version: 2025-10-14_v1
 */

$route['dashboard'] = 'dashboard/index';
